import assert from 'node:assert/strict';
import {loadEngine} from '../lib/engine.mjs';
import {loadVatOwner} from '../lib/owner.mjs';
import {roundReference} from '../lib/money.mjs';
import {calculateVat} from '../lib/vat.mjs';

if(!process.env.OPENERP_REPO)throw new Error('OPENERP_REPO is required. Owner verification is never silently skipped.');
const owner=await loadVatOwner({repoRoot:process.env.OPENERP_REPO});
const e=await loadEngine();
let comparisons=0;
for(const rounding of ['half_up','half_even','toward_zero','floor'])
 for(const n of [-1000n,-300n,-250n,-100n,-1n,0n,1n,150n,10n**38n-1n])
  for(const d of [1n,2n,10n,100n,1000000n]){
   const expected=roundReference(n,d,rounding).value;
   assert.equal(owner.round(n,d,rounding),expected,`Owner mismatch: ${n}/${d} mode=${rounding}. See the optional negative-floor patch.`);comparisons++;
  }
for(const rounding of ['half_up','half_even','toward_zero','floor'])
 for(let filingUnitScale=0;filingUnitScale<=6;filingUnitScale++){
  const contributions=[{box:'05',signedMinor:'100000',included:true},{box:'10',signedMinor:'25000',included:true},{box:'11',signedMinor:'-100',included:true},{box:'48',signedMinor:'101',included:true}];
  const input={contributions,filingUnitScale,rounding,declareNet:true};
  assert.deepEqual(calculateVat(e,input),owner.boxRows({filingUnitScale,rounding},contributions,true));comparisons++;
 }
console.log(JSON.stringify({status:'owner-monetary-differential-passed',comparisons,checker:e.authority,fullEligibilityOrFilingVerified:false}));
