/* SPDX-License-Identifier: AGPL-3.0-only
 * Extracted monetary functions from erik-kroon/openERP
 * commit 0eaad6402241ff3853fdc1af015e13f343873641
 * jurisdictions/se/src/vat/actual.ts
 * Full upstream blob: 2006b670d926c2d11713375ab2de5bcdc6da9181
 * These are source excerpts, not a complete copy or a legal VAT specification.
 * The floor bug is intentionally retained for the regression test.
 */
type Rounding = 'half_up' | 'half_even' | 'toward_zero' | 'floor';
const netBox = "49";
const inputBox = "48";
const primitiveBoxes = ["05", "10", "11", "12", "48"];
const saleOutputBoxes = ["10", "11", "12"];

function round(numerator: bigint, denominator: bigint, mode: Rounding) {
  if (denominator <= 0n) return null;

  const negative = numerator < 0n;
  const magnitude = negative ? -numerator : numerator;
  const quotient = magnitude / denominator;
  const remainder = magnitude % denominator;
  const doubled = remainder * 2n;

  const rounded =
    mode === "toward_zero"
      ? quotient
      : mode === "floor"
        ? negative
          ? quotient + 1n
          : quotient
        : mode === "half_even"
          ? doubled > denominator || (doubled === denominator && quotient % 2n === 1n)
            ? quotient + 1n
            : quotient
          : doubled >= denominator
            ? quotient + 1n
            : quotient;

  return negative ? -rounded : rounded;
}

function taxed(basisMinor: bigint, rate: Rate, mode: Rounding) {
  return round(basisMinor * BigInt(rate.numerator), BigInt(rate.denominator), mode);
}

function reportedIn(exact: bigint, unit: bigint, mode: Rounding) {
  const reported = round(exact, unit, mode);

  if (reported === null) return null;

  return { reported, residual: exact - reported * unit };
}

function boxRows(
  release: typeof Release.VatFilingRuleRelease.Type,
  contributions: ReadonlyArray<Contribution>,
  declareNet: boolean,
) {
  const unit = 10n ** BigInt(release.filingUnitScale);
  const totals = new Map<string, bigint>();

  for (const contribution of contributions) {
    const value = BigInt(contribution.signedMinor);

    totals.set(contribution.box, (totals.get(contribution.box) ?? 0n) + value);
  }

  const rows: Array<typeof Vat.VatActualBox.Type> = [];

  for (const box of primitiveBoxes) {
    if (!totals.has(box)) continue;
    const exact = totals.get(box) ?? 0n;
    const scaled = reportedIn(exact, unit, release.rounding);

    if (scaled === null) continue;

    rows.push({
      box,
      kind: "primitive",
      exactMinor: exact.toString(),
      reportedMinor: scaled.reported.toString(),
      residualMinor: scaled.residual.toString(),
    });
  }

  // The net is derived from the reported primitive boxes, not from the exact net,
  // because a filing reports whole units. Both are retained and their difference
  // is the residual. Assume nothing about the reported figure equalling the
  // rounded exact figure.
  if (!declareNet) return rows;

  let exactNet = 0n;
  let reportedNet = 0n;

  for (const box of saleOutputBoxes) {
    if (!totals.has(box)) continue;
    const exact = totals.get(box) ?? 0n;
    const scaled = reportedIn(exact, unit, release.rounding);

    if (scaled === null) return rows;

    exactNet += exact;
    reportedNet += scaled.reported;
  }

  if (totals.has(inputBox)) {
    const exact = totals.get(inputBox) ?? 0n;
    const scaled = reportedIn(exact, unit, release.rounding);

    if (scaled === null) return rows;

    exactNet -= exact;
    reportedNet -= scaled.reported;
  }

  rows.push({
    box: netBox,
    kind: "net",
    exactMinor: exactNet.toString(),
    reportedMinor: reportedNet.toString(),
    residualMinor: (exactNet - reportedNet * unit).toString(),
  });

  return rows;
}

// Test-only exports. No changes are made to the application's source file.
export { round, taxed, reportedIn, boxRows };
