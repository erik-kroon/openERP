# OpenERP Bend verification kit

An isolated implementation of the four requested workstreams: ledger/allocation verification, a VAT monetary model, binary arbitrary-precision arithmetic and the PRY-33 covering-set solver.

**This is working source with executable tests, not a production posting engine.** No OpenERP file, database, approval or deployed service has been changed.

## Start here

Use Node 22.16 or later. The archive has no npm dependencies and does not require `npm install`.

```sh
cd openerp-bend-kit
npm test
npm run demo
npm run check:proofs
```

`npm test` checks the Bend implementations against independent JS BigInt calculations, brute-force subset enumeration and the retained VAT source excerpt. It writes `evidence/test-report.json`. The demonstration prints voucher validation, allocation conservation, VAT residuals and two conflicting covering witnesses.

### Verification status

The included evidence was produced with the **development adaptation** of the published Bend source checker in `tooling/dev-checker.ts`. It parses and checks the actual `.bend` files, then evaluates those files. The arithmetic is not a JavaScript reimplementation masquerading as Bend.

However, this checker was reconstructed from published source excerpts and is not byte-identical to upstream. The official Bend binary, its `--safe` kernel and its C/Metal/CUDA backends were not available in the authoring environment. **Their validation is still required.** Passing development checks is not an official compiler certification or a proof of OpenERP production correctness.

To replace the adaptation with the exact pinned upstream checker:

```sh
BEND_SOURCE_ROOT=/absolute/path/to/bend npm test
```

The loader verifies `bend2/bend.ts` against its pinned Git blob hash and refuses a mismatch. It does not silently fall back.

The complete model-verification gate requires an upstream checkout, an installed Bend command and an OpenERP checkout:

```sh
export BEND_SOURCE_ROOT=/absolute/path/to/bend
export BEND_BIN=/absolute/path/to/bend-command
export OPENERP_REPO=/absolute/path/to/openERP
npm run verify:release
```

This runs pinned-source checks, all executable tests, real-owner monetary differential checks, the official compiler and `bend/PROOF.bend --safe`. Missing tools or mismatches fail the gate. Even a successful gate is not a statutory-compliance or full ERP readiness certificate.

## What is implemented

| Workstream | Implementation |
| --- | --- |
| Verification harness | `LAWS.bend` and `PROOF.bend` contain 20 completed law/proof pairs. Ledger acceptance carries balance, valid-line and minimum-line witnesses. Allocation acceptance carries separate source and target conservation witnesses. |
| VAT model | `Vat.bend` aggregates explicitly included contributions into boxes 05, 10, 11, 12 and 48. It retains exact, reported and residual amounts. Box 49 derives from reported primitive boxes, not by rounding the exact net. |
| Exact arithmetic | `BigNat.bend`, `BigInt.bend`, `Rational.bend` and `Decimal.bend` implement binary naturals, signed integers, checked subtraction, multiplication, divmod, GCD, reduced fractions, six rounding policies and typed decimal conversion. No native U32 or F32 carries money. |
| PRY-33 solver | `Cover.bend` searches exact subsets of full remaining capacities. It returns unique-within-scope, ambiguous, no-match-within-scope, incomplete or unavailable through the host adapter. One global node budget bounds the search. |

The JS adapter supports OpenERP's canonical integer-string boundary with up to 38 digits. Arithmetic intermediates are not restricted to 38 digits. Input currency, scale, direction and snapshot scope remain explicit.

## A real upstream regression

At the inspected OpenERP commit, `jurisdictions/se/src/vat/actual.ts` increments a negative quotient in `floor` mode even when the division is exact:

```text
round(-100, 100, "floor")
upstream: -2
correct:  -1
```

`patches/0001-fix-negative-exact-floor.patch` changes the increment condition to require a nonzero remainder. The original bug remains in the retained test excerpt so the regression cannot disappear silently.

The main kit tests confirm the original failure and compare the corrected in-memory source with Bend. **The strict real-owner gate intentionally fails against the unpatched owner.** It does not apply the patch for you.

Review and apply it from your OpenERP checkout:

```sh
git apply --check /absolute/path/to/openerp-bend-kit/patches/0001-fix-negative-exact-floor.patch
git apply /absolute/path/to/openerp-bend-kit/patches/0001-fix-negative-exact-floor.patch
OPENERP_REPO="$PWD" node --experimental-strip-types /absolute/path/to/openerp-bend-kit/scripts/verify-owner.mjs
```

The patch is optional until reviewed. No tax-policy choice is implied by fixing the mathematical meaning of an already selected rounding mode.

## Integration boundary

Copy this directory into `verification/bend/` or keep it alongside OpenERP. Do not replace `packages/domain`, `jurisdictions/se` or application operations as the first integration step.

```text
immutable captured inputs
        |
        v
Bend calculations / solver
        |
        v
exact host validation and explained suggestions
        |
        v
existing Effect prepare / review / approve / execute
        |
        v
existing PostgreSQL transaction and receipts
```

The harness has no database driver or credentials. Every solver result has `mayExecute: false` and `requiresRevalidation: true`. Its input fingerprint is a verification artifact identity, not an OpenERP canonical digest or an approval token.

## Important scope limits

The VAT model covers the **monetary projection after contribution qualification**. It does not reimplement the full `calculateActualVat` eligibility, coverage or control-reconciliation pipeline. Real-owner checks exercise the owner's `round` and `boxRows` functions through test-only exports, without editing the owner.

Twenty selected properties have proof terms. This does **not** mean every arithmetic algorithm, the solver's search completeness, the TypeScript bridge or PostgreSQL's transaction behavior has a universal proof. The detailed separation is in `docs/PROOF-COVERAGE.md`.

The solver is currently a deterministic CPU reference search. It is not a measured GPU implementation. It selects whole remaining capacities, not arbitrary fractional allocations, fee plugs, FX differences or cross-currency matches.

## Contents

```text
bend/          Bend 2 kernels, law declarations and proof terms
lib/           typed host boundary and research evaluator
scripts/       demos and fail-closed verification gates
tests/         deterministic differential and negative tests
upstream/      retained VAT monetary excerpt with provenance
patches/       optional one-line floor correction
evidence/      actual test output, results and verification status
docs/          integration, proof coverage and trust boundary
```

Source pins:

- OpenERP: `0eaad6402241ff3853fdc1af015e13f343873641`
- Bend: `af569d4826913b2ce3557e9829ccad31fcf86f94`

See `docs/SOURCES.md`, `NOTICE` and `LICENSE` for provenance and licensing.
